# Arquivo de exemplo para testar o sistema
# Este arquivo será substituído por vídeos reais

echo "Vídeo de exemplo para testes" > exemplo.txt

